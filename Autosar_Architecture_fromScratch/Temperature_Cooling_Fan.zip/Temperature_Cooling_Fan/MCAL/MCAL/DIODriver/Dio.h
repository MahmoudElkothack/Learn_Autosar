

typedef unsigned int Dio_LevelType
typedef unsigned int Dio_ChannelType

#define STD_LOW		0x00
#define STD_HIGH	0x01