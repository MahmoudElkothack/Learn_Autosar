

typedef unsigned int Adc_GroupType
typedef unsigned int Adc_ValueGroupType